global.DEBUG = true;
require('./mafia.js');