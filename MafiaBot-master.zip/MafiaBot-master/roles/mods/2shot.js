module.exports = {
    id: '2shot',
    name: '2-Shot',
    description: 'You can fire your ability twice in a game instead of once.',
    mod: {
        ammo: 2,
    },
};