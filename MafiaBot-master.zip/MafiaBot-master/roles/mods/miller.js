module.exports = {
    id: 'miller',
    name: 'Miller',
    description: 'You scan as scum to cops, regardless of role.',
    mod: {
        forceInnocent: false,
    },
};