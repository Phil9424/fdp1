module.exports = {
    id: 'inno',
    name: 'Innocent-scanning',
    description: 'You scan as innocent to cops, regardless of role.',
    mod: {
        forceInnocent: true,
    },
};