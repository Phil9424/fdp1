module.exports = {
    token: 'TOKEN GOES HERE',
}